// Start a new profile from profiles/_template: `npm run profile:new -- <name>`
// <name> is lowercase letters, digits and dashes. Refuses to touch a profile that already exists.
import { readdir, copyFile, mkdir } from 'node:fs/promises';
import { existsSync } from 'node:fs';

const root = new URL('../', import.meta.url);
const name = process.argv[2];
if (!/^[a-z0-9][a-z0-9-]{0,39}$/.test(name ?? '')) {
  console.error('Usage: npm run profile:new -- <name>   (lowercase letters, digits and dashes)');
  process.exit(1);
}
const template = new URL('profiles/_template/', root);
const dest = new URL(`profiles/${name}/`, root);
if (existsSync(dest)) {
  console.error(`profiles/${name} already exists; edit it instead.`);
  process.exit(1);
}

await mkdir(new URL('data/', dest), { recursive: true });
const files = await readdir(template);
for (const f of files) await copyFile(new URL(f, template), new URL(f, dest));
console.log(`Created profiles/${name} (${files.join(', ')}). Run any script with --profile ${name}.`);
